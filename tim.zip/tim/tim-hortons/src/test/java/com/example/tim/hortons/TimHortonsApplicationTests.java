package com.example.tim.hortons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimHortonsApplicationTests {

	@Test
	void contextLoads() {
	}

}
