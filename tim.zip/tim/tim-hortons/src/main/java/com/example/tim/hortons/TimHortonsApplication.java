package com.example.tim.hortons;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TimHortonsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TimHortonsApplication.class, args);
	}

}
